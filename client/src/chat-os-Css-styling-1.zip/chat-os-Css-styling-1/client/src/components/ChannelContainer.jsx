import React from 'react'

const ChannelContainer = () => {
  return (
    <div>ChannelContainer</div>
  )
}

export default ChannelContainer